<nav id="sub_menu">
	<ul>
		<li><a href="#">인사말</a></li>
		<li><a href="#">기업연혁</a></li>
		<li><a href="#">뉴스센터</a></li>
		<li><a href="#">사회공헌</a></li>
	</ul>
</nav>