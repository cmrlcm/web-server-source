<nav id="sub_menu">
	<ul>
		<li><a href="#">Join Us</a></li>
		<li><a href="#">Privacy Policy</a></li>
	</ul>
</nav>